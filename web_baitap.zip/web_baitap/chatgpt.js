$(document).ready(function(){
	$('#action_menu_btn').click(function(){
		$('.action_menu').toggle();
	});
});
const chatMsg = document.getElementById('chatMsg');
		const userInput = document.getElementById('userInput');
		const sendButton = document.querySelector('button');
		
		function sendMessage() {
			const question = userInput.value.trim();
			if (question === '') return;
			
			displayMessage(question, 'user');
			userInput.value = '';
		
			fetchResponse(question)
				.then(response => {
					displayMessage(response, 'bot');
				})
				.catch(error => {
					console.error('Error fetching response:', error);
					displayMessage('Sorry, something went wrong.', 'bot');
				});
		}
		userInput.addEventListener('keypress', function(event) {
			if (event.key === 'Enter') {
				event.preventDefault(); // Prevent default form submission
				sendMessage();
			}
		});
		function fetchResponse(question) {
			const apiKey = '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';
			const endpoint = 'https://api.openai.com/v1/chat/completions';
			const requestBody = {
				model: 'gpt-3.5-turbo',
				messages: [
					{ role: 'user', content: question }
				],
				max_tokens: 500,
				temperature: 0.7
			};
		
			return fetch(endpoint, {
				method: 'POST',
				headers: {
					'Content-Type': 'application/json',
					'Authorization': `Bearer ${apiKey}`
				},
				body: JSON.stringify(requestBody)
			})
			.then(response => response.json())
			.then(data => {
				const botResponse = data.choices[0].message.content;
				return botResponse;
			});
		}
		
		function displayMessage(message, sender) {
    const chatMsg = document.getElementById('chatMsg');
    const msgElement = document.createElement('div');
    msgElement.classList.add('msg_container');

    const userMessageHtml = `
        <div class="d-flex justify-content-start mb-4">
            <div class="img_cont_msg">
                <img src="https://static.turbosquid.com/Preview/001292/481/WV/_D.jpg" class="rounded-circle user_img_msg">
            </div>
            <div class="msg_cotainer">
                ${message}
                <span class="msg_time">8:40 AM, Today</span>
            </div>
        </div>
    `;
    const botMessageHtml = `
        <div class="d-flex justify-content-end mb-4">
            <div class="msg_cotainer_send">
                ${message}
                <span class="msg_time_send">8:55 AM, Today</span>
            </div>
            <div class="img_cont_msg">
                <img src="https://avatars.hsoubcdn.com/ed57f9e6329993084a436b89498b6088?s=256" class="rounded-circle user_img_msg">
            </div>
        </div>
    `;

    const innerHtml = sender === 'user' ? userMessageHtml : botMessageHtml;
    msgElement.innerHTML = innerHtml;
    chatMsg.appendChild(msgElement);
    chatMsg.scrollTop = chatMsg.scrollHeight;
}
		// Voice Recognition
		function startVoiceRecognition() {
			const recognition = new webkitSpeechRecognition(); // For Chrome
			// const recognition = new SpeechRecognition(); // For modern browsers
			recognition.continuous = false;
			recognition.lang = 'vi-VN'; // Set language to Vietnamese
		
			recognition.onresult = function(event) {
				const result = event.results[0][0].transcript;
				userInput.value = result;
			}
		
			recognition.onerror = function(event) {
				console.error('Speech recognition error:', event.error);
			}
		
			recognition.onend = function() {
				sendMessage();
			}
		
			recognition.start();
		}